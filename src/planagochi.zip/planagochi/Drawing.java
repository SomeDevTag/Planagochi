package planagochi;

import java.awt.Color;

public class Drawing {
	public int PixelColor[];
	Drawing() {
		PixelColor = new int[30 * 30];
		
		
		for(int i = 0; i < 30*30 ; i++) {			
			PixelColor[i] = 0;
		}
	}
}
