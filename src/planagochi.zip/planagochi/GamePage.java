package planagochi;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JPanel;
import java.util.Random;


public class GamePage extends JPanel implements ActionListener,MouseListener,MouseMotionListener,KeyListener {
	Random rand = new Random();
	
	//Storing all the plants and their prices
	ArrayList<Plant> plants = new ArrayList<Plant>();
	//Store all body assets
	ArrayList<features> body = new ArrayList<features>();
	int hair = 0;
	int shirt= 0;
	int eyes = 0;
	int mouth = 0;
	 Color black = new Color(0 , 0 , 0);
	 Color darkgray = new Color(50 , 50 , 50);
	 Color lightgray =  new Color(150 , 150 , 150 );
	 Color backgroundColor =  new Color(100 , 100 , 100 );
	 Color ScreenBackColor =  new Color( 200 , 200, 200);
	 Color ScreenFrontColor =  new Color( 90 , 90, 90);
	 Color button1 =  new Color(232, 186, 86);
	 Color button2 = new Color(107, 189, 92);
	 Color button3 =  new Color(227, 82, 75);
	 int CurrentState = 0;
	 int Hydration = 6;
	 int state = 3;
	 int currentplant= 0;
	 int plantselector= 0;
	 int money = 0;
	 
	 int bodyselector = 0;
	 
	 boolean aot = true;
	 
	 MainPage dada;
	 
	 
	 // Settings in the start
	GamePage(MainPage dad){
		
		dada = dad;
		this.setFocusable(true);
		this.setBackground(backgroundColor);
		this.addMouseMotionListener(this);
		this.addMouseListener(this);
		this.setPreferredSize(new Dimension(760 ,320));
		setCursor(new java.awt.Cursor(java.awt.Cursor.CROSSHAIR_CURSOR));
		this.requestFocus();
		this.addKeyListener(this);	
	
		this.setLayout(null);
		
		
		repaint();
		
		}
		
	
	
	// This function is for rendering.
	public void paint(Graphics g){
		
		  super.paint(g);
	        Graphics2D g2D =  (Graphics2D) g ;  
//	        g2D.drawString("RonaGachi", 380, 30);
	        
	        //Buttons Colors
	        g2D.setStroke(new BasicStroke(3));
	        g2D.setColor(ScreenBackColor);
	        g2D.fillRect(10, 10, 540, 320);
	    	g2D.setColor(button1);
	        g2D.fillRect(570, 50, 80, 80);
	    	g2D.setColor(button2);
 		 	g2D.fillRect(570, 210, 80, 80);
 			g2D.setColor(button3);
 		 	g2D.fillRect(670, 130, 80, 80);
 		 	g2D.setColor(button3);
 		 	g2D.fillRect(730, 10, 20, 20);
 		 	
 			g2D.setColor(darkgray);
 			g2D.fillRect(670, 10, 40, 20);
 		 	if(aot) {
 		 		g2D.setColor(Color.green);	 	
 		 		g2D.fillRect(690, 10, 20, 20);
 		 	}else {
 		 		g2D.setColor(ScreenBackColor);	
 		 		g2D.fillRect(670, 10, 20, 20);
 		 	}
	        	        
 		 	//Outlines the buttons and screens
 		 	g2D.setColor(darkgray);
 			g2D.drawRect(1, 1, 758, 338);
 		 	g2D.drawRect(10, 10, 540, 320);
 		 	g2D.drawRect(570, 50, 80, 80);
 		 	g2D.drawRect(570, 210, 80, 80);
 		 	g2D.drawRect(670, 130, 80, 80);
 			g2D.drawRect(670, 10, 40, 20);
 			g2D.drawRect(730, 10, 20, 20);
 			
 			
 		 	// Drawing inside the screen
 		 	g2D.setColor(ScreenFrontColor);
 		 	 
 		 	// rendering inside the screen depending on the "state" aka what the screen is
 		 	 switch( state) {
 		 	 case 0: 
 		 		 // All the text on the screen
 	 		 	 g2D.drawString(plants.get(currentplant).Name, 325, 50);
 	 		 	 if(plants.get(currentplant).length - CurrentState - 1  != 0) {
 	 		 		g2D.drawString(plants.get(currentplant).length - CurrentState - 1 + " hours left", 325, 70);
 	 		 	 }else {
 	 		 		g2D.drawString( "Harvest now!", 325, 70);
 	 		 	 }	 	 
 	 		 	g2D.drawString( "$ : " + money, 445, 30);
 	 		 	
 	 		 	// Drawing Hydration bar
 	 		    for(int i = 0; i<   Hydration; i++) {
 			    	 g2D.fillRect(500, 50*i+25, 40, 40);
 			     }
 	 			g2D.drawRect(495 , 20 , 50 , 300);
 	 			
 	 			//Rendering the plant
 	 		      for(int i = 0; i<   30; i++) {
 	 		    	  for(int j = 0; j<30 ; j++) {
 	 		    		  if(   plants.get(currentplant).pixels[i+(j*30)][CurrentState] == 0) {
 	 		    			  g2D.setColor(ScreenFrontColor);
 	 		    		  }else {
 	 		    			  g2D.setColor(ScreenBackColor);
 	 		    		  }
 	 		    		 
 	 		    		  g2D.fillRect((i*10)+21, (j*10)+21, 8, 8);
 	 		    		 
 	 		    	  } 
 	 		      }	
 	 		      
 	 		      //Outlining the plant 
 	 		    g2D.setColor(ScreenFrontColor);
	 		 	 
 			 	g2D.drawRect(20, 20, 300, 300);
 			 	
 			 	
 			 	//Mini character rendering
 			   for(int i = 0; i<   30; i++) {
	 		    	  for(int j = 0; j<30 ; j++) {
	 		    		  if(   body.get(hair).pixels[i+(j*30)] == 0 
	 		    				||   body.get(shirt +5).pixels[i+(j*30)] == 0 
	 		    				||   body.get(eyes +10).pixels[i+(j*30)] == 0 
	 		    				||   body.get(mouth +15).pixels[i+(j*30)] == 0 
	 		    				  ) {
	 		    			  g2D.setColor(ScreenFrontColor);
	 		    		  }else {
	 		    			  g2D.setColor(ScreenBackColor);
	 		    		  }
	 		    		 
	 		    		  g2D.fillRect((i*5)+330, (j*5)+170, 5, 5);
	 		    		 
	 		    	  } 
	 		      }	
 	 		      
 	 		      
 		 		 
 		 		 break;	 
 		 	 case 1:
 		 		 //All the texts on the shopping menu
 		 		g2D.drawString( "$ : " + money, 445, 30);
 		 		 g2D.drawString(plants.get(plantselector%9).Name, 325, 50);
 		 		g2D.drawString(plants.get(plantselector%9).length - 1 + " hours long", 325, 70);
 		 		if(plants.get(plantselector%9).price > money)
 		 		g2D.drawString("Today's price: " +   plants.get(plantselector%9).price + " $ - Can't buy", 325, 90);
 		 		else
 		 		g2D.drawString("Today's price: " +   plants.get(plantselector%9).price + " $", 325, 90);
 		 		g2D.drawString("Todays's Sell: " +  plants.get(plantselector%9).sell + " $", 325, 110);
 		 		 
 		 		
 		 		//Rendering all the plants in the right positions
 		 		 for(int p = 0; p<   9; p++) {
 	 		 		 for(int i = 0; i<   30; i++) {
 	 	 		    	  for(int j = 0; j<30 ; j++) {
 	 	 		    		  if(   plants.get(p).pixels[i+(j*30)][plants.get(p).length-1] == 0) {
 	 	 		    			  if(plants.get(p).price > money) {
 	 	 		    				  g2D.setColor(lightgray);
 	 	 		    			  }else {
 	 	 		    				  g2D.setColor(ScreenFrontColor);
 	 	 		    			  }

 	 	 		    		  }else {
 	 	 		    			  g2D.setColor(ScreenBackColor);
 	 	 		    		  }
 	 	 		    		 
 	 	 		    		  g2D.fillRect((i*3)+100*(p/3)+25, (j*3)+100*(p%3)+25,3, 3);
 	 	 		    		 
 	 	 		    	  } 
 	 	 		      }		
 	 		 		 
 	 		 		 //Rendering the selector box 
 	 		 		 if(p == plantselector%9) {
 	 		 		 g2D.setColor(ScreenFrontColor);
 	 		 		  g2D.drawRect(100*(p/3)+25, 100*(p%3)+25,90, 90);
 	 		 		 }
 	 		 		 }
 		 		 
 		 		 //Highlighting the work area
 	 		 		 
 	 		 		 g2D.setColor(ScreenFrontColor);
 	 		 	 	g2D.drawRect(20, 20, 300, 300);
 	 		 		 
 	 		 		 
 		 		 
 		 		 break;
 		 		
 		 	 case 2:
 		 		 
 		 		 //This menu is between growing and shop to show price of sold item.
 		 		g2D.drawString( "$ : " + money, 445, 30);
 		 		g2D.drawString( "Earned: " + plants.get(plantselector%9).sell +"$" , 200, 150);
 		 		g2D.drawString( "Press Any button to continue..." , 200, 170);
 		 		
 		 		 
 		 		 
 		 		 break;
 		 	 case 3:
 		 		 //loading screen (barely visible but better than nothing to reduce launching lag.
 		 		 
 		 		g2D.drawString( "Loading Assets..." , 200, 150);
 		 		loadplants();
 		 		loadbody();
 		 		state = 0;
 		 		 break;
 		 	 case 4:
 		 		 //Character customization screen
 		 		 
 		 		 
 		 		 //Rendering the character
 		 	   for(int i = 0; i<   30; i++) {
	 		    	  for(int j = 0; j<30 ; j++) {
	 		    		  if(   body.get(hair).pixels[i+(j*30)] == 0 
	 		    				||   body.get(shirt +5).pixels[i+(j*30)] == 0 
	 		    				||   body.get(eyes +10).pixels[i+(j*30)] == 0 
	 		    				||   body.get(mouth +15).pixels[i+(j*30)] == 0 
	 		    				  ) {
	 		    			  g2D.setColor(ScreenFrontColor);
	 		    		  }else {
	 		    			  g2D.setColor(ScreenBackColor);
	 		    		  }
	 		    		 
	 		    		  g2D.fillRect((i*10)+20, (j*10)+20, 10, 10);
	 		    		 
	 		    	  } 
	 		      }	
 		 	   //all the text
 		 	  g2D.setColor(ScreenFrontColor);
 				g2D.drawString("Hair: " +   hair , 325, 90);
 				g2D.drawString("Mouth: "+   shirt, 325, 110);
 				g2D.drawString("Eyes: " +   eyes , 325, 130);
 				g2D.drawString("Mouth: "+   mouth , 325, 150);
 				//rendering an arrow on the item being changed 
 				g2D.drawString("< < <" , 400, 20*bodyselector+90);
 		 		 
 		 		 break;
 		 	 
 		 	 
 		 	 }	 	 
	    }
	public void closeapp() {
		// this method will be used for initating saving later on
		// it allows you to call a method before closing the app
		System.out.print("bbye");
		System. exit(0);
	}
	
	
	public void loadplants() {
		//loading the plants and initiating the arraylists with the correct variables and assets
		   for(int plant = 0 ; plant <9 ; plant++) {
		  try {
		        File myObj = new File("p" + plant + ".rona");
		        Scanner myReader = new Scanner(myObj);
		        
		        //Name of plant
		        String data = myReader.next();
		        String name = data;
		        System.out.print("p" + plant + ".rona" + " - plant loaded. \n");
		        data = myReader.next();
		        
		        plants.add(new Plant(Integer.valueOf(data)));
		        plants.get(plant).Name = name;
		        int amountofpages = Integer.valueOf(data);
		        plants.get(plant).price = amountofpages* (rand.nextInt(5)+1);
		        plants.get(plant).sell =   plants.get(plant).price + rand.nextInt(12);
		        System.out.print(amountofpages + " pages. \n");
		           for(int p = 0 ; p <amountofpages ; p++) {
		        	   
		        	   for(int i = 0 ; i<30*30 ; i++){
		        		   
		        		   data = myReader.next();
		        		  
		        		   plants.get(plant).pixels[i][p] = Integer.valueOf(data);	        		   
		           		}	        	 
		           }
		        myReader.close();
		        
		        System.out.print(  plants.get(plant).Name  + "\n");
		      } catch (FileNotFoundException e) {
		        System.out.println("An error occurred.");	      
		      }
		   }
		   
		 
		   repaint();
	}
	
	public void loadbody() {
		// loading the body assets and putting them into the "body arraylist"
		  try {
		        File myObj = new File("cosms.rona");
		        Scanner myReader = new Scanner(myObj);	        
		        //these variables arent needed but better than making a whole new file type.
		        String data = myReader.next();
		        String name = data;
		        System.out.print("Cosmetics loaded. \n");
		        data = myReader.next();	               
		        int amountofpages = Integer.valueOf(data);		    
		        System.out.print(amountofpages + " features \n");
		       
		           for(int p = 0 ; p <amountofpages ; p++) {
		        	   body.add(new features(Integer.valueOf(data)));		    
		        	   for(int i = 0 ; i<30*30 ; i++){	        		   
		        		   data = myReader.next();	        		  
		        		   body.get(p).pixels[i] = Integer.valueOf(data);	        		   
		           		}	        	 
		           }	        
		        myReader.close();	        	      
		      } catch (FileNotFoundException e) {
		        System.out.println("An error occurred.");	      
		      }
		   repaint();
	}
	
	
	
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		// these are admin controls will be removed later
		System.out.print("Typed\n");
		switch(e.getKeyChar()) {
		case 'p':
			//removing water
			if(Hydration > 0) {
				Hydration--;
				repaint();
			}
			break;
		case '[':	
			//ungrowing
			if(CurrentState > 0) {
				 CurrentState--;		
			 }
			break;
		case ']':
			//growing
			 if(plants.get(currentplant).length > CurrentState+1) {
				 CurrentState++;			
			 }
			break;
			
		}
		repaint();
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub

		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		//Calling the correct methods when clicking on buttons since i am not using buttons instead rendering them.
		 if(e.getButton() == MouseEvent.BUTTON1) {
			
			 if(e.getX() > 570 && e.getY() > 50  && e.getX() < 650 && e.getY() < 130) {

				button1();
				 			 
			 }else  if(e.getX() > 570 && e.getY() > 210  && e.getX() < 650 && e.getY() < 290) {

				button2();
				
			 }else if(e.getX() > 670 && e.getY() > 130  && e.getX() < 750 && e.getY() < 210) {
				 
				button3();
			
			 }else if(e.getX() > 670 && e.getY() > 10  && e.getX() < 710 && e.getY() < 30) {
			
				aot = !aot;
				dada.setAlwaysOnTop(aot);
			 }else if(e.getX() > 730 && e.getY() > 10  && e.getX() < 750 && e.getY() < 30) {
				closeapp();
				
			 }
			 
			 repaint();
		 }
		
	}
	
	public void button1() {
		switch(state) {
		case 0:
			bodyselector = 0;
			state = 4;
			break;
		case 1:
			 plantselector++;
			break;
		case 2:
			 state = 1;
			break;
		case 4:
		
			switch(bodyselector) {
			case 0:
				hair = (hair+1)%5;
				break;
			case 1:
				shirt = (shirt+1)%5;
				break;
			case 2:
				eyes = (eyes+1)%5;
				break;
			case 3:
				mouth = (mouth+1)%5;
				break;
			}
			break;
		}
	}
	
	public void button2() {
		switch(state) {
		case 0:
			
			break;
		case 1:
			if( plantselector > 0){
				 plantselector--;
			 }
			break;
		case 2:
			 state = 1;
			break;
		case 4:
			switch(bodyselector) {
			case 0:
				if(hair > 0)
					hair--;
					else
						hair = 4;
				break;
			case 1:
				if(shirt > 0)
					shirt--;
					else
						shirt = 4;
				break;
			case 2:
				if(eyes > 0)
					eyes--;
					else
						eyes = 4;
				break;
			case 3:
				if(mouth > 0)
					mouth--;
					else
						mouth = 4;
				break;
			}
			
		
			
			break;
		}
	}
	
	public void button3() {
		switch(state) {
		case 0:
			 if(plants.get(currentplant).length - CurrentState - 1  == 0) {			 
				 state = 2;
					money +=plants.get(currentplant).sell;
			 }
			 Hydration = 6;
			break;
		case 1:
			 if(plants.get(plantselector%9).price <= money) {
			 currentplant = plantselector%9;
			 money -= plants.get(plantselector%9).price;
			 state = 0;
			 CurrentState = 0;
			 }
			break;
		case 2:
			
			 state = 1;
			break;
		case 4:
			if(bodyselector < 3)
				bodyselector++;
				else
					state = 0;
			break;
		}
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
