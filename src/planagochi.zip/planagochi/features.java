package planagochi;

public class features {
	public int pixels[];
	public int length;
	features( int amount) {
		pixels = new int[30*30];
		length = amount;
	
		for(int i = 0; i < 30*30 ; i++) {			
			pixels[i]= 0;
		}
	}
	
}
