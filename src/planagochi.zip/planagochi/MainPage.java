package planagochi;

import java.awt.Dimension;

import javax.swing.JFrame;

public class MainPage  extends JFrame {
	
	
	public void RUN() {

	 	this.setTitle("RonaGachi" );
	   
	   
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	
       // this.setTitle("Pixies");
        this.add(new GamePage(this));
        this.pack();
        this.setLocationRelativeTo(null);
//        this.setUndecorated(true);
        this.setMinimumSize(new Dimension(760 ,340 ));
        this.setVisible(true);
        this.setResizable(false);
        this.setAlwaysOnTop( true );
//        this.setDefaultLookAndFeelDecorated(false);
      
        
	}

}
