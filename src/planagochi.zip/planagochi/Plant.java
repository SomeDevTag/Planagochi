package planagochi;

import java.awt.Color;

public class Plant {
	public int pixels[][];
	public String Name;
	public int length;
	public int price;
	public int sell;
	Plant( int amount) {
		pixels = new int[30*30][amount];
		length = amount;
		for(int j = 0; j < amount ; j++) {
		for(int i = 0; i < 30*30 ; i++) {			
			pixels[i][j] = 0;
		}
	}
	}
}
