package planagochi;

public class starter {
public static void main(String args[]) {
	MainPage b = new MainPage();
	b.setUndecorated(true);
	b.RUN();
}
}
